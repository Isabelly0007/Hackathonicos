const { app, BrowserWindow } = require('electron');

const DURACAO_MIN = 5200; // ms: tempo da animação de abertura completa

function criarSplash() {
  const w = new BrowserWindow({
    width: 640, height: 520,
    frame: false, resizable: false, center: true,
    show: false, alwaysOnTop: true, skipTaskbar: true,
  });
  w.loadFile('splash.html', { query: { modo: 'abertura' } });
  w.once('ready-to-show', () => w.show());
  return w;
}

function criarJanelaPrincipal() {
  const w = new BrowserWindow({ width: 1280, height: 800, show: false });
  w.loadFile('index.html'); // troque pela tela do sistema Taylor
  return w;
}

app.whenReady().then(async () => {
  const splash = criarSplash();
  const principal = criarJanelaPrincipal();

  let pronta = false;
  const prontaP = new Promise((resolve) =>
    principal.once('ready-to-show', () => { pronta = true; resolve(); })
  );

  await new Promise((r) => setTimeout(r, DURACAO_MIN));

  // Se o sistema ainda não carregou, a splash passa para o modo carregamento (repete, com frase)
  if (!pronta) {
    splash.webContents.executeJavaScript("setModo('carregamento')");
    await prontaP;
  }

  splash.close();
  principal.show();
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
